package com.pig.embeded;

import java.io.IOException;
import java.util.Properties;
import org.apache.pig.ExecType;
import org.apache.pig.PigServer;
import org.apache.pig.backend.executionengine.ExecException;
/**
 * 
 * @author Iqubal Mustafa Kaki
 *
 */
public class EmbededPigScriptInsideJava {

	public static void main(String args[]) throws ExecException
	{
		Properties p=new Properties();
		p.setProperty("fs.default.name", "hdfs://localhost:8020/");
		p.setProperty("mapred.job.tracker", "localhost:8021");
		PigServer pigServer=new PigServer(ExecType.LOCAL, p);
		
		try {
			runMyQuery(pigServer, "bollywood_hit_movies.csv");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void runMyQuery(PigServer pigServer, String inputfile) throws IOException {
		
		pigServer.setJobName("Embedded PIG Statements in JAVA");
		pigServer.registerQuery("bollywood_hit = LOAD '" + inputfile + "' Using PigStorage(',') AS (year: int, movie: chararray,lead_actor:chararray);");
		pigServer.registerQuery("actor_superhits = GROUP bollywood_hit BY lead_actor;");
		pigServer.registerQuery("number_of_hits = FOREACH actor_superhits GENERATE group, COUNT(bollywood_hit);");
		pigServer.store("number_of_hits", "actor_superhit_dir");
	}
}
